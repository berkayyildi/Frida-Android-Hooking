#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_noplay_myapplication_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */
        ,jstring jstr) {

    const char* str = env->GetStringUTFChars(jstr,0);

    char result[100] = "";   // array to hold the result.

    strcat(result,str); // append string two to the result.
    strcat(result," BERKAY"); // append string two to the result.

    return env->NewStringUTF(result);
}
